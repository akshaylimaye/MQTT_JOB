package mqttPrac;

import java.util.Random;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class publisherJob implements Job {
	Random rand = new Random();
	int value = rand.nextInt(1000);
	MqttClient client = Publisher.getInstance().getClient();
	MqttMessage message = new MqttMessage();

	public void execute(JobExecutionContext context) throws JobExecutionException {
		String occupancy = String.valueOf(value);
		message.setPayload(occupancy.getBytes());

		try {
			client.publish("GET_CURRENT_OCCUPANCY", message);
			client.disconnect();
			client.close();
		} catch (MqttPersistenceException e) {
			e.printStackTrace();
		} catch (MqttException e) {
			e.printStackTrace();
		}

	}

}
