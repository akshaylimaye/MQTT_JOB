package mqttPrac;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class CallBack implements MqttCallback {

	public void connectionLost(Throwable cause) {
		System.out.println("Connection with mqtt broker lost");

	}

	public void messageArrived(String topic, MqttMessage message) throws Exception {
		System.out.println("Message-" + message + " with topic-" + topic + " arrived at-" +System.currentTimeMillis());

	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("Message was succesfully deliverd!");

	}

}
