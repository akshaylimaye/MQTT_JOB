package mqttPrac;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class ApplicationStart {

	public final String triggerName = "mqttTrigger";
	public final static String group = "mqttGroup";
	public final String jobName = "mqttJob";
	public static Scheduler schedular = null;

	public static void main(String args[]) {

		Subscriber subscriber = new Subscriber();

		try {
			subscriber.getInstance().subscribe();
			schedular = new StdSchedulerFactory().getScheduler();
			JobDetail job = JobBuilder.newJob(publisherJob.class).withIdentity(group).build();
			CronTrigger trigger = TriggerBuilder.newTrigger()
					.withSchedule(CronScheduleBuilder.cronSchedule("0/10 * * * * ?")).build();
			schedular.scheduleJob(job, trigger);
			schedular.start();

		}

		catch (MqttException e) {
			e.printStackTrace();
		}

		catch (SchedulerException e) {
			e.printStackTrace();
		}
	}

}
